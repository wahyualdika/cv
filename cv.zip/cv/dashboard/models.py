from django.db import models
from resume.models import MassageResume


# Create your models here.
