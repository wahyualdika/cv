from django.urls import path,include
from django.conf.urls import url
from . import views
# from .models import Berita,Peta

app_name = "dashboard"

urlpatterns = [
    path('', views.index, name='index'),
    path('detail_massage/<int:pk>',views.MassageDetailView.as_view(),name='massage_detail'),
    path('massage/<int:pk>/delete/',views.MassageDeleteView.as_view(),name='massage_delete'),
    path('reply_form/',views.replyForm,name='replay-form'),
    path('send_reply/massage/<int:pk>',views.replyMassage,name='reply'),
]
