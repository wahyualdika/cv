from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.core.mail import send_mail
from django.views.generic.detail import DetailView
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from resume.models import MassageResume
from django.conf import settings
from .forms import ReplyForm
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
# Create your views here.

decorators = [login_required]

@login_required
def index(request):
    massages = MassageResume.objects.all()
    context = {
        'massages' : massages,
    }
    return render(request,'dashboard/index.html',context)

@method_decorator(decorators, name='dispatch')
class MassageDetailView(DetailView):
    context_object_name = 'massage'
    model = MassageResume
    template_name = 'dashboard/detail-message.html'

@login_required
def replyMassage(request,pk):
    if request.method == 'POST':
        form = ReplyForm(request.POST)
        if form.is_valid():
             subject = form.cleaned_data['subject']
             message = form.cleaned_data['massage']
             email_from = settings.EMAIL_HOST_USER
             sender = form.cleaned_data['recipient']
             recipient_list = [sender,]
             send_mail( subject, message, email_from, recipient_list )
             return render(request,'dashboard/index.html',context)
    else:
        return HttpResponseRedirect('detail_massage/')

@login_required
def replyForm(request):
    return render(request,'dashboard/form.html')

@method_decorator(decorators, name='dispatch')
class MassageDeleteView(DeleteView):
    model = MassageResume
    template_name = 'dashboard/massage_confirm_delete.html'
    success_url = reverse_lazy('dashboard:index')
    context_object_name = 'massage'
