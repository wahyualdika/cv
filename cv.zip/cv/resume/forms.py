from django import forms

class ResumeForm(forms.Form):
    name = forms.CharField(max_length=100)
    massage = forms.CharField(widget=forms.Textarea)
    email = forms.EmailField()
    subject = forms.CharField(max_length=100)
