from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import MassageResume
from django.conf import settings
from .forms import ResumeForm

def index(request):
    return render(request,'resume/index.html')

def message(request):
    if request.method == 'POST':
        form = ResumeForm(request.POST)
        post = MassageResume()
        if form.is_valid():
            post.name = form.cleaned_data['name']
            post.email = form.cleaned_data['email']
            post.subject = form.cleaned_data['subject']
            post.massage = form.cleaned_data['massage']
            post.save()
            return HttpResponseRedirect(reverse('main_page:thanks'))

    else:
        return render(request,'resume/index.html')

    return render(request,'base.html',{'form': form})

def thanks_massage(request):
    return render(request,'resume/thanks.html')
