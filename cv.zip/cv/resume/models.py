from django.db import models

# Create your models here.
class MassageResume(models.Model):
    name = models.CharField(max_length = 50)
    email =  models.EmailField(max_length = 255)
    massage = models.TextField()
    subject = models.CharField(max_length = 150)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)

    def get_absolute_url(self):
        return reverse('main_page:message')

    def __str__(self):
        return self.name
