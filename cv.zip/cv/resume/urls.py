from django.urls import path,include
from . import views
from django.contrib.auth import authenticate, login
# from .models import Berita,Peta

app_name = "main_page"

urlpatterns = [
    path('', views.index, name='index'),
    path('post/', views.message, name='message'),
    path('thanks/',views.thanks_massage, name='thanks'),
]
