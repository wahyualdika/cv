from django.contrib import admin
from .models import MassageResume
# Register your models here.
admin.site.register(MassageResume)
